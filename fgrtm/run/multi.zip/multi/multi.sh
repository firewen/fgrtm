#!/bin/bash
sdir=$1
dep1=$2
dep2=$3
ddep=$4

for (( i=dep1; i<=dep2; i=i+ddep))
do
	evdp=$(echo $i | awk '{printf("%3.1f",$1 * 0.2)}')
	#evdp=$(echo $i | awk '{printf("%3.1f",$1 * 3)}')
	echo $evdp
	fname="serial.sh"
echo "#!/bin/bash" > $fname
echo "#SBATCH -J dep$evdp" >> $fname
echo "#SBATCH -N 1" >> $fname
echo "#SBATCH -n 1" >> $fname
echo "#SBATCH -t 60:00" >> $fname
echo "#SBATCH -o dep$evdp.o" >> $fname
echo "#SBATCH -e dep$evdp.e" >> $fname
echo "" >> $fname
echo "sh sgreen_gen.sh $sdir ../layered_model.dat $evdp 1024 0.01 " >> $fname
#echo "sh sgreen_gen.sh $sdir ../layered_model.dat $evdp 2048 0.10 " >> $fname
#cat $fname

sbatch $fname
done
