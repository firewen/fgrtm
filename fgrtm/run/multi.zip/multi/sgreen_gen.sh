#!/bin/bash

# go inside the event directory
cd $1

# generate station list
#cat ../20190622142956/sdc1.txt | awk '{print "grep "$1" sdc.txt"}' | sh > sdc1.txt

# velocity model
vmodel=$2

# source depth
evdp=$3

# npts & dt
npts=$4
m0=$(awk -v npts=$npts 'BEGIN{print log(npts)/log(2)}')
dt=$5

#dfile=data
#if [ ! -d "$dfile" ]
#then
#        mkdir $dfile
#fi
dfile=gfun$evdp
if [ ! -d "$dfile" ]
then
        mkdir $dfile
fi

cd $dfile

pwd
stftype=Green	
cat ../sdc.txt | while read line
do
	echo $line
        stname=$(echo $line | awk '{print $1}')
        stx=$(echo $line | awk '{print $2}')
        sty=$(echo $line | awk '{print $3}')
        sth=$(echo $line | awk '{print $4}')

	m=$(awk -v stx=$stx -v sty=$sty -v m=$m0 'BEGIN{if(sqrt(stx*stx+sty*sty)>500)m=m+1;print m}')
	Twin=$(awk 'BEGIN{ARGC=2;nt=2^ARGV[1];dt=ARGV[2];print (nt-1)*dt}' $m $dt)
	#echo $stname $stx $stftype $evdp $m $Twin $dt $m0
	sh ../green.sh $stname $stx $sty $sth $stftype $evdp $vmodel $m $Twin

done

cd ../

