
fname=$1.txt

stname=$1
rx=$2
ry=$3
rh=$4
stf=$5
evdp=$6
vmodel=$7
npts=$8
Twin=$9

echo "FOR :  receiver information: rarray case:" > $fname
echo 						 >> $fname 
echo "20.00           -- x0(m)"		 >> $fname
echo "10.00            -- y0(m)"		 >> $fname
echo " 0.00           -- z0(m)"		 >> $fname
echo						 >> $fname
echo "FOR :  input data for double-couple source:" >> $fname
echo 						 >> $fname
echo " 0 1e7         --    M0 (dyne cm)"	 >> $fname
echo " 1 "					 >> $fname
echo " 1 1 1 0 0 0   -- mxx,myy,mzz,mxy,mxz,myz / dip, rake, str" >> $fname
echo " 0.0         --   xs(m) "			 >> $fname
echo " 0.0         --   ys(m) "			 >> $fname
echo "10.0          --   zs(m) "			 >> $fname
echo 						 >> $fname
echo "FOR :  basic control parameters & source parameters" >> $fname
echo 						 >> $fname
echo "(1). Basic control parameters:" 		 >> $fname
echo " 12         !--    m     : NT=2**m   ( max(m)=11 )" >> $fname
echo " 204.75     !--   Twin   : time window (second)" >> $fname
echo 						 >> $fname
echo "(3). Source spectral parameters:" 	 >> $fname
echo "Ramp       !-- Type_STF :type of source-time function, 'Ricker', 'Ramp', 'Exp'," >> $fname
echo "                      : 'SSTEP', 'Exp', 'Green','Bouchon','Trapezoid','B(shift)'" >> $fname
echo "0.5      !--    tou   : rise time  (second)" >> $fname
echo "0.0       !--   shift  : time shift (second)" >> $fname
echo "60.       !--    fc    : center frequency (Hz)" >> $fname
echo 						 >> $fname
echo "(4). Window swith and parameters:"	 >> $fname
echo "OFF       !--WinSwitch : 'ON'--use filter, 'OFF'--do not use filter" >> $fname
echo "Hamming   !-- WinType  : 'Hamming'--Hamming filter, 'Butter'--???" >> $fname
echo "0.01      !-- f1 (Hz)"			 >> $fname
echo "0.07      !-- f2 (Hz)"			 >> $fname
echo "96.50      !-- f3 (Hz)"			 >> $fname
echo "99.30      !-- f4 (Hz)"			 >> $fname
echo 						 >> $fname
echo "(5). Output Format:"			 >> $fname
echo "st1       !-- prefix for output filename"  >> $fname
echo 						 >> $fname
echo "FOR :   multi-layered media model" 	 >> $fname
echo "Number of total layers:"			 >> $fname
nlayer=$(cat $vmodel | awk 'END{print NR}')
echo $nlayer					 >> $fname
echo "Layer #   depth(km)   Densities(g/cm3)  S-Velocity(km/s) P-velocity(km/s) Qs-values  Qp-values" >> $fname
cat $vmodel | awk '{print NR,$1,$4,$2,$3,600.00,800.00}' >> $fname

#	change information about stations	
	sttmp=$(echo $stname)
	tmp=$sttmp.dat
	echo $tmp
# change station coordinates
	cp $fname $tmp
	cat $tmp | sed "3 s/20.00/$rx/" > $fname
	cp $fname $tmp
	cat $tmp | sed "4 s/10.00/$ry/" > $fname
	cp $fname $tmp
	cat $tmp | sed "5 s/0.00/$rh/" > $fname
# change source coordinates
#	cp $fname $tmp
#	cat $tmp | sed "13 s/0.0/$sty/" > $fname
	cp $fname $tmp
	cat $tmp | sed "14 s/10.0/$evdp/" > $fname
# change npts and Twin
	cp $fname $tmp
	cat $tmp | sed "19 s/12/$npts/" > $fname
	cp $fname $tmp
	cat $tmp | sed "20 s/204.75/$Twin/" > $fname
	
# change stf
	cp $fname $tmp
	cat $tmp | sed "23 s/Ramp/$stf   /" > $fname

#	change the name of record
	cp $fname $tmp
	cat $tmp | sed "s/st1/$sttmp/" > $fname
	mv $fname $tmp
	
#      	add random to velocity

	echo
	grep $sttmp $tmp

	 ~/data/idstest/green/bin/MainProgram $tmp
	 #~/tmpsoft/idstest/fgrtm/bin/MainProgram $tmp

#	echo $sttmp $stx $sty	>> ss1.txt
	echo $sttmp 
#        mv $sttmp*.dat ../data
#        mv $sttmp*.sac ./data
#	mv g_$sttmp* ./gfun$evdp
	
echo "End computation"
